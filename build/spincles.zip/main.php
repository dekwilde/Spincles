<?php require( 'includes/header.php' ); ?>
<body>
	<?php 
		//require("view/audio.php");
		require("view/zig.php");
		require("view/game.php"); 
	?>
    <div id="fb-root"></div>
</body>
<?php require( 'includes/footer.php' ); ?>