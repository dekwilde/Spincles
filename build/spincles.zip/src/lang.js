
	
	
	// AVISOS

	var error_str = "Erro ao gravar informações. Inicie o processo novamente.\nSe o problema persistir entre em contato com o nosso suporte.\nObrigado";
	var error_nome = "Nome incompleto! Digite o nome e sobrenome";
	var error_email = "Email invalido";

	// cadastro
	var error_confirm = "Confirme a senha";
	var error_pass = "Senha não confere";
	var null_senha = "Preencha a senha";
	var null_email = "Preencha o email";
	var null_pais = "Selecione um país";
	var null_estado = "Preencha um Estado";
	var null_cidade = "Preencha uma Cidade";
	var null_cep = "Preencha um CEP";
	var null_atividade = "Selecione uma atividade";
	var null_abelhas = "Selecione um tipo";
	var null_exploracao = "Selecione uma exploração";
	var null_aceito = "Por favor, aceite as regras do regulamento.";
	var error_double = "Email já cadastrado. Por favor, escolha outro email ou tente recuperar seu cadastro. Obrigado.";
	var error_recover = "Email não encontrado, verifique o email digitado. Obrigado.";

	// login
	var status_recover = "A senha foi enviada para seu email.";
	var error_recover = "Email não encontrado, verifique o email digitado. Obrigado.";
	var error_login = "Usuário não encontrado";

  
