<div data-role="page" data-control-title="Spincles" data-theme="a" id="game">
    <div data-role="content" style="padding:0px">
		<canvas id="pde"></canvas>
    </div>
</div>

